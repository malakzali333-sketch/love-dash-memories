OUR LITTLE UNIVERSE — WEBSITE FILES

1. Upload index.html to the root of your GitHub repository.
2. Add your own images to the same folder (repository root) using these exact filenames:
   - childhood-photo.jpg
   - our-photo.jpg
   - love-letter-moon.jpg
   JPG, PNG, or WEBP files are fine if you also change the matching filename in index.html.
3. Keep GitHub Pages set to deploy from main / (root).
4. Password: love
5. The YouTube song is embedded near the beginning. The visitor may need to tap Play because browsers block autoplay.

Page order:
Password -> animated stars/light -> Welcome to 26 -> song -> childhood photo -> couple photo -> moonlight love-letter image.

All visible website text is English. There are no captions under the photos and no wishes section.
